//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : CLASS FOR USER TO INPUT CHOICE
package com.items.test;

import java.util.Scanner;

import com.items.service.*;

public class SalesReport {
	//MAIN METHOD
	public static void main(String[] args) {
		int choice = 0;
		ProductService productService = new ProductServiceImpl();
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("MENU");
			System.out.println("Enter 1 to add new item, 2 to display report, ans 3 to exit.\nEnter choice : ");
			choice = sc.nextInt();
			switch(choice) {
			case 1: //CALLING TO BUSSINESS LAYER TO ADD ITEM
					productService.addProductItems();
					break;
					
			case 2: //CALLING TO BUSSINESS LAYER TO DISPLAY REPORT
					productService.displayReport();
					break;
			case 3: //TO EXIT PROGRAM
					System.exit(0);
			
			}
		} while(choice != 3);
		
		sc.close();
	}

}
