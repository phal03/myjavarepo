//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : CLASS IN DATA ACCESS LAYER TO ACCESS DATA
package com.items.dao;



import java.util.TreeSet;

import com.items.bean.Product;

public class ProductDaoImpl implements ProductDao {
	
	TreeSet<Product> itemList = new TreeSet<>();
	TreeSet<Product> topItemList = null;
	
	
	//METHOD TO ADD NEW ITEM
	@Override
	public void newItem(Product product) {
		itemList.add(product);
	}

	//METHOD TO DISPLAY REPORT
	@Override
	public void displayTopItems() {
		topItemList = (TreeSet<Product>)itemList.descendingSet();
		int count = 0;
		for(Product item : topItemList){
            System.out.println(item);
            if(++count == 3)
            	break;
		}
	}

}
