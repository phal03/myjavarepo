//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : INTERFACE FOR PRODUCTDAO CLASS TO IMPLEMENT
package com.items.dao;

import com.items.bean.Product;

public interface ProductDao {

	//TO ADD NEW ITEM
	void newItem(Product product);
	
	//TO DISPLAY REPORT
	void displayTopItems();

}
