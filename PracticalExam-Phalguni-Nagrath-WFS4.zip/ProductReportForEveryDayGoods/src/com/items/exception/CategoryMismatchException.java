//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : EXCEPTION CLASS TO THROW CATEGORY MISMATCH EXCEPTION 

package com.items.exception;

public class CategoryMismatchException extends Exception{
	
	public CategoryMismatchException(String message) {
		super(message);
	}
	
}
