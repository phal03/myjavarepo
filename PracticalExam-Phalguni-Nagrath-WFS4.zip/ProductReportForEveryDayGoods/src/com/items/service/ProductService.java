//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : INTERFACE FOR PRODUCTSERVICE CLASS TO IMPLEMENT
package com.items.service;

public interface ProductService {

	void addProductItems();

	void displayReport();

}
