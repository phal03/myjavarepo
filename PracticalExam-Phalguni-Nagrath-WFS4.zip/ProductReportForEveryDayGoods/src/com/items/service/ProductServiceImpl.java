//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : CLASS TO IMPLEMENT THE BUSSINESS LAYER
package com.items.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.items.bean.*;
import com.items.dao.*;
import com.items.exception.CategoryMismatchException;

public class ProductServiceImpl implements ProductService {
	static {
		sc=new Scanner(System.in);
		sdf=new SimpleDateFormat("dd/MM/yyyy");
	}
	static Scanner sc;
	static SimpleDateFormat sdf;
	private ProductDao productDao;
	
	public ProductServiceImpl() {
		this.productDao = new ProductDaoImpl();
	}

	//TO ADD NEW ITEMS
	public void addProductItems() {
		Product product = null;
		System.out.println("Enter Item Code : ");
		int itemCode = sc.nextInt();
		System.out.println("Enter Item Name : ");
		String itemName = sc.next();
		System.out.println("Enter unit price : ");
		double unitPrice = sc.nextDouble();
		System.out.println("Enter quantity : ");
		int quantity = sc.nextInt();

		System.out.println("Enter category :");
		System.out.println("'f' to input FOOD ITEMS, 'a' to input APPARELS, 'e' to input ELECTRONICS\nEnter choice : ");
		try {
		char type = sc.next().charAt(0);
		Character.isLowerCase(type);
		Date dtManufacture = null;
		Date dtExpiry = null;
		if(type == 'f') {
			try {
				System.out.println("Enter Date of Manufacture in dd/mm/yyyy format : ");
				String dt = sc.next();
				//TO CONVERT STRING TO DATE FORMAT
				dtManufacture = sdf.parse(dt);
				System.out.println("Enter Date of Expiry in dd/mm/yyyy format : ");
				dt = sc.next();
				dtExpiry = sdf.parse(dt);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Enter whether vegetarian in yes/no : ");
			String choice = sc.next();
			product = new FoodItems(itemCode, itemName, unitPrice, quantity, dtManufacture, dtExpiry, choice);
			productDao.newItem(product);
		}

		else if(type == 'a') {
			System.out.println("Enter size small, medium, or large : ");
			String size = sc.next();
			System.out.println("Enter material whter cotton or wool : ");
			String material = sc.next();
			product = new Apparel(itemCode, itemName, unitPrice, quantity, size, material);
			productDao.newItem(product);
		}
		
		else if(type == 'e') {
			System.out.println("Enter warranty in months : ");
			int warranty = sc.nextInt();
			product = new Electronics(itemCode, itemName, unitPrice, quantity, warranty);
			productDao.newItem(product);
		}
		
		else
			throw new CategoryMismatchException("Wrong choice of category!!");
		
		} catch (CategoryMismatchException e) {
			System.out.println(e.getMessage());
		}
	}

	//TO DISPLAY REPORT
	@Override
	public void displayReport() {
		productDao.displayTopItems();
		
	}


}
