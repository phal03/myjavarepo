//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : CHILD CLASS OF PRODUCT THAT STORES VALUES FOR APPAREL CATEGORY
package com.items.bean;

public class Apparel extends Product{
	private String size;
	private String material;
	
	//DEFAULT CONSTRUCTOR FOR CHILD CLASS
	public Apparel() {
		super();
		size = null;
		material = null;
	}

	//PARAMETERIZED CONSTRUCTOR FOR CHILD CLASS
	public Apparel(int itemCode, String itemName, double unitPrice, int quantity, String size, String material) {
		super();
		this.size = size;
		this.material = material;
	}
	
	//SETTER AND GETTER METHODS TO SET AND RETRIEVE VALUES
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	
	//TO PRINT THE VALUES OF DIFFERENT PARAMETERS
	@Override
	public String toString() {
		return super.toString() + "Apparel [size=" + size + ", material=" + material + "]\n";
	}
}
