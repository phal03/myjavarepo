//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : CHILD CLASS OF PRODUCT THAT STORES VALUES FOR ELECTRONICS CATEGORY
package com.items.bean;

public class Electronics extends Product{
	
	private int warranty;
	
	//DEFAULT CONSTRUCTOR FOR CHILD CLASS
	public Electronics() {
		super();
		warranty = 0;
	}

	//PARAMETERIZED CONSTRUCTOR FOR CHILD CLASS
	public Electronics(int itemCode, String itemName, double unitPrice, int quantity, int warranty) {
		super();
		this.warranty = warranty;
	}

	//SETTER AND GETTER METHODS TO SET AND RETRIEVE VALUES
	public int getWarranty() {
		return warranty;
	}

	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}

	//TO PRINT THE VALUES OF DIFFERENT PARAMETERS
	@Override
	public String toString() {
		return "Electronics [warranty=" + warranty + "]\n";
	} 
	
}
