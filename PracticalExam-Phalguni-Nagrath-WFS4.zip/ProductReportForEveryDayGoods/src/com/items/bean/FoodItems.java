//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : CHILD CLASS OF PRODUCT THAT STORES VALUES FOR FOOD ITEM CATEGORY
package com.items.bean;

import java.util.Date;

public class FoodItems extends Product{
	private Date dtManufacture;
	private Date dtExpiry;
	private String vegetarian;
	
	//DEFAULT CONSTRUCTOR FOR CHILD CLASS
	public FoodItems() {
		super();
		dtManufacture = null;
		dtExpiry = null;
		vegetarian = null;
	}
	
	//PARAMETERIZED CONSTRUCTOR FOR CHILD CLASS
	public FoodItems(int itemCode, String itemName, double unitPrice, int quantity, Date dtManufacture, Date dtExpiry, String vegetarian) {
		super();
		this.dtManufacture = dtManufacture;
		this.dtExpiry = dtExpiry;
		this.vegetarian = vegetarian;
	}
	
	//SETTER AND GETTER METHODS TO SET AND RETRIEVE VALUES
	public Date getDtManufacture() {
		return dtManufacture;
	}

	public void setDtManufacture(Date dtManufacture) {
		this.dtManufacture = dtManufacture;
	}
	public Date getDtExpiry() {
		return dtExpiry;
	}
	public void setDtExpiry(Date dtExpiry) {
		this.dtExpiry = dtExpiry;
	}
	public String getVegetarian() {
		return vegetarian;
	}
	public void setVegetarian(String vegetarian) {
		this.vegetarian = vegetarian;
	}
	
	//TO PRINT THE VALUES OF DIFFERENT PARAMETERS
	@Override
	public String toString() {
		return super.toString() + "FoodItems [dtManufacture=" + dtManufacture + ", dtExpiry=" + dtExpiry + ", vegetarian=" + vegetarian
				+ "]";
	}
	
}
