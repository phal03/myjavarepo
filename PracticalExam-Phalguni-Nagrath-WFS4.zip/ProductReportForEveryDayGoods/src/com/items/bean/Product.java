//AUTHOR : PHALGUNI NAGRATH>
//PURPOSE : BASE CLASS THAT HAS COMMON VARIABLES
package com.items.bean;

public class Product implements Comparable<Product>{
	private int itemCode;
	private String itemName;
	private double unitPrice;
	private int quantity;
	
	//DEFAULT CONSTRUCTOR FOR BASE CLASS I.E. PRODUCT
	public Product() {
		this.itemCode = 0;
		this.itemName = null;
		this.unitPrice = 0.0;
		this.quantity = 0;
	}
	
	//PARAMETERIZED CONSTRUCTOR FOR BASE CLASS I.E. PRODUCT
	public Product(int itemCode, String itemName, double unitPrice, int quantity) {
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
	}

	//SETTER AND GETTER METHODS TO SET AND RETRIEVE VALUES
	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	//TO PRINT THE VALUES OF DIFFERENT PARAMETERS
	public String toString() {
		return "Product [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice + ", quantity="
				+ quantity + "]\n";
	}

	@Override
	public int compareTo(Product p) {
		// TODO Auto-geneObject arg0rated method stub
		return 0;
	}
	
	
}
